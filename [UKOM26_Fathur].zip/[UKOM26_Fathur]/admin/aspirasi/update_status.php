<?php
session_start();
include "../../includes/koneksi.php";

if($_SESSION['role'] != "admin"){
    exit;
}

$id     = $_POST['id'];
$status = $_POST['status'];

mysqli_query($koneksi,"
UPDATE tb_aspirasi
SET status='$status'
WHERE id_aspirasi='$id'
");

header("location:index.php");
exit;
?>
