<?php
include "../../includes/koneksi.php";

$id   = $_POST['id'];
$nama = $_POST['nama'];

mysqli_query($koneksi,"UPDATE tb_kategori SET nama_kategori='$nama' WHERE id_kategori='$id'");

header("location:index.php?msg=1");
?>