<?php
include "../../includes/koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama_kelas   = mysqli_real_escape_string($koneksi, $_POST['nama_kelas']);
    $tahun_ajaran = mysqli_real_escape_string($koneksi, $_POST['tahun_ajaran']);

    $sql = "INSERT INTO tb_kelas (nama_kelas, tahun_ajaran, created_at)
            VALUES ('$nama_kelas', '$tahun_ajaran', NOW())";

    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        header("Location: index.php?tambah=success");
        exit;
    } else {
        echo "Gagal menambah data: " . mysqli_error($koneksi);
    }
}
?>
