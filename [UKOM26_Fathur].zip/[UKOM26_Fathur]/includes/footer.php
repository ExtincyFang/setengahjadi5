    </div> <!-- tutup flex-fill -->

</div> <!-- tutup d-flex -->

<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
